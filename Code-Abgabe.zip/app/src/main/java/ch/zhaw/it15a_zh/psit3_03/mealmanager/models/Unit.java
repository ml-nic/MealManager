package ch.zhaw.it15a_zh.psit3_03.mealmanager.models;

/**
 * Enum for units.
 */
public enum Unit {
    g, kg, l, ml, Stück, TL
}
